import java.util.*;
public class Main {
    public static void main(String[] args)
	{ Scanner ps = new Scanner(System.in);
			Set<Integer> s = new TreeSet<Integer>();
	    int num  = ps.nextInt();
		int[] arr = new int[num];
		for(int i = 0;i<num;i++){
		    arr[i] = ps.nextInt();
	s.add(arr[i]);	}
		int k = ps.nextInt();
		k--;
		Iterator<Integer> itr = s.iterator();
		while(k>0)
		{
		itr.next();
		k--;
		}
		System.out.println(itr.next());
	}
}
